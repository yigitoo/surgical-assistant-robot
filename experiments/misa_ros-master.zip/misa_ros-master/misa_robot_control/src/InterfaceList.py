from enum import Enum

class InterfaceList(Enum):
    
