from FileManager import FileManager


fg = FileManager(master_name = "KinovaTestLog", subfolder_name = "KinovaAPIServer")
fg.write_line("This is a test line bitch \n")
