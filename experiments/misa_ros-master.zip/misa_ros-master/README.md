# misa_ros
Minimally Invasive Robotic Assistant, Özyeğin Üniversity, 2019, Murat ÖZVİN.

Package Requires:
  Ubuntu 16.04,
  ROS-kinetic-desktop-full pakages especially including ros_control, ros_gazebo packages.
  Python 2.7
